# MASK — STEMs, Crafting, Living Plants

## STEMs
- Totem-style save: if you hold a STEM and would die, it shatters and you survive at 50% HP
- Craft at 3x3 table (crystal ring + torch center) or find in chests

## Crafting
- **CRAFT** button: 2x2 by default (inventory crafting)
- Stand next to a **Craft Table** in the world → CRAFT opens **3x3**
- Recipes for torches, weapons, armor pieces, STEM

## Trees & plants
- **Cylindrical** trunks (CylinderMesh)
- Leaf canopies + flowers **sway / breathe** in the wind

## Consistency
Systems share one item ID scheme, one inventory UI, one player controller, and one dimension manager.
Prototype limits remain (no disk save of player inventory mid-session, mesh rebuild mining cost).
